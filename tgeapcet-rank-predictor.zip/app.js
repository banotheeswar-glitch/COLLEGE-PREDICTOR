// TGEAPCET College Predictor App
class CollegePredictor {
    constructor() {
        this.collegeData = [];
        this.filteredResults = [];
        this.currentSort = { column: null, direction: 'asc' };
        this.branchCodes = {
            "CSE": "COMPUTER SCIENCE AND ENGINEERING",
            "ECE": "ELECTRONICS AND COMMUNICATION ENGINEERING",
            "EEE": "ELECTRICAL AND ELECTRONICS ENGINEERING",
            "MEC": "MECHANICAL ENGINEERING",
            "CIV": "CIVIL ENGINEERING",
            "CSM": "COMPUTER SCIENCE AND ENGINEERING (AI & ML)",
            "CSD": "COMPUTER SCIENCE AND ENGINEERING (DATA SCIENCE)",
            "INF": "INFORMATION TECHNOLOGY",
            "ANE": "AERONAUTICAL ENGINEERING",
            "CHE": "CHEMICAL ENGINEERING",
            "BIO": "BIO-TECHNOLOGY",
            "BME": "BIO-MEDICAL ENGINEERING"
        };
        this.collegeTypes = {
            "PVT": "Private",
            "GOV": "Government", 
            "UNIV": "University",
            "SF": "Self Finance"
        };
        
        this.init();
    }

    async init() {
        await this.loadData();
        this.bindEvents();
        this.populateBranchFilter();
    }

    async loadData() {
        try {
            const response = await fetch('https://ppl-ai-code-interpreter-files.s3.amazonaws.com/web/direct-files/b85e6034e5be6353189cb31132727ab1/e3345d90-5a0b-47a7-9b22-1d00fd4f9c39/3d646753.csv');
            const csvText = await response.text();
            this.collegeData = this.parseCSV(csvText);
            console.log(`Loaded ${this.collegeData.length} college records`);
        } catch (error) {
            console.error('Error loading data:', error);
            // Fallback to sample data if CSV fails to load
            this.collegeData = this.getSampleData();
        }
    }

    parseCSV(csvText) {
        const lines = csvText.split('\n');
        const headers = lines[0].split(',').map(h => h.trim().replace(/"/g, ''));
        const data = [];

        for (let i = 1; i < lines.length; i++) {
            const line = lines[i].trim();
            if (!line) continue;
            
            const values = this.parseCSVLine(line);
            if (values.length < headers.length) continue;
            
            const record = {};
            headers.forEach((header, index) => {
                let value = values[index] ? values[index].replace(/"/g, '').trim() : '';
                
                // Convert numeric fields
                if (header.includes('BOYS') || header.includes('GIRLS') || 
                    header.includes('EWS') || header === 'Tuition_Fee' || 
                    header === 'Year_of_Estab') {
                    value = value === '' ? null : parseInt(value) || null;
                }
                
                record[header] = value;
            });
            
            data.push(record);
        }
        
        return data;
    }

    parseCSVLine(line) {
        const result = [];
        let current = '';
        let inQuotes = false;
        
        for (let i = 0; i < line.length; i++) {
            const char = line[i];
            
            if (char === '"') {
                inQuotes = !inQuotes;
            } else if (char === ',' && !inQuotes) {
                result.push(current);
                current = '';
            } else {
                current += char;
            }
        }
        
        result.push(current);
        return result;
    }

    getSampleData() {
        return [
            {
                "Inst_Code": "AARM",
                "Institute_Name": "AAR MAHAVEER ENGINEERING COLLEGE",
                "Place": "BANDLAGUDA",
                "Dist_Code": "HYD",
                "Co_Education": "COED",
                "College_Type": "PVT",
                "Year_of_Estab": 2010,
                "Branch_Code": "CSE",
                "Branch_Name": "COMPUTER SCIENCE AND ENGINEERING",
                "OC_BOYS": 26588,
                "OC_GIRLS": 29938,
                "BC_A_BOYS": 52666,
                "BC_A_GIRLS": 62471,
                "BC_B_BOYS": 38568,
                "BC_B_GIRLS": 38568,
                "BC_C_BOYS": 26588,
                "BC_C_GIRLS": 108434,
                "BC_D_BOYS": 38368,
                "BC_D_GIRLS": 38368,
                "BC_E_BOYS": 53852,
                "BC_E_GIRLS": 53852,
                "SC_BOYS": 70513,
                "SC_GIRLS": 75671,
                "ST_BOYS": 70477,
                "ST_GIRLS": 83930,
                "EWS_GEN_OU": 30771,
                "EWS_GIRLS_OU": 38034,
                "Tuition_Fee": 60000,
                "Affiliated_To": "JNTUH"
            }
        ];
    }

    bindEvents() {
        const form = document.getElementById('prediction-form');
        const applyFiltersBtn = document.getElementById('apply-filters');
        const tableHeaders = document.querySelectorAll('.results-table th[data-sort]');

        form.addEventListener('submit', (e) => this.handleFormSubmit(e));
        applyFiltersBtn.addEventListener('click', () => this.applyFilters());
        
        tableHeaders.forEach(header => {
            header.addEventListener('click', () => this.handleSort(header.dataset.sort));
        });
    }

    populateBranchFilter() {
        const branchFilter = document.getElementById('branch-filter');
        const branches = [...new Set(this.collegeData.map(college => college.Branch_Code))].filter(Boolean);
        
        branches.sort().forEach(branchCode => {
            const option = document.createElement('option');
            option.value = branchCode;
            option.textContent = `${branchCode} - ${this.branchCodes[branchCode] || branchCode}`;
            branchFilter.appendChild(option);
        });
    }

    async handleFormSubmit(e) {
        e.preventDefault();
        
        const rank = parseInt(document.getElementById('rank').value);
        const gender = document.getElementById('gender').value;
        const category = document.getElementById('category').value;

        if (!rank || !gender || !category) {
            alert('Please fill in all required fields');
            return;
        }

        if (rank < 1 || rank > 200000) {
            alert('Please enter a valid rank between 1 and 200000');
            return;
        }

        this.showLoading();
        
        // Simulate processing time
        setTimeout(() => {
            this.processResults(rank, gender, category);
            this.hideLoading();
            this.showResults();
        }, 1000);
    }

    processResults(userRank, gender, category) {
        const results = [];
        
        this.collegeData.forEach(college => {
            const cutoffRank = this.getCutoffRank(college, gender, category);
            
            if (cutoffRank && userRank <= cutoffRank) {
                const chanceLevel = this.calculateChanceLevel(userRank, cutoffRank);
                
                // Skip girls-only colleges for male students
                if (gender === 'Male' && college.Co_Education === 'GIRLS') {
                    return;
                }
                
                results.push({
                    ...college,
                    cutoffRank,
                    chanceLevel,
                    chanceDifference: cutoffRank - userRank
                });
            }
        });

        // Sort by chance level and then by cutoff rank
        results.sort((a, b) => {
            if (a.chanceLevel !== b.chanceLevel) {
                const chanceOrder = { 'high': 0, 'moderate': 1, 'low': 2 };
                return chanceOrder[a.chanceLevel] - chanceOrder[b.chanceLevel];
            }
            return b.chanceDifference - a.chanceDifference;
        });

        this.filteredResults = results;
        this.updateStatistics();
        this.renderResults();
    }

    getCutoffRank(college, gender, category) {
        let columnName;
        
        if (category === 'EWS') {
            columnName = gender === 'Male' ? 'EWS_GEN_OU' : 'EWS_GIRLS_OU';
        } else {
            const genderSuffix = gender === 'Male' ? 'BOYS' : 'GIRLS';
            columnName = `${category}_${genderSuffix}`;
        }
        
        return college[columnName];
    }

    calculateChanceLevel(userRank, cutoffRank) {
        const difference = cutoffRank - userRank;
        const percentage = (difference / cutoffRank) * 100;
        
        if (percentage >= 20) return 'high';
        if (percentage >= 5) return 'moderate';
        return 'low';
    }

    updateStatistics() {
        const totalOptions = this.filteredResults.length;
        const govtColleges = this.filteredResults.filter(r => r.College_Type === 'GOV').length;
        const privateColleges = this.filteredResults.filter(r => r.College_Type === 'PVT').length;
        const fees = this.filteredResults.map(r => r.Tuition_Fee).filter(f => f > 0);
        const minFee = fees.length > 0 ? Math.min(...fees) : 0;

        document.getElementById('total-options').textContent = totalOptions;
        document.getElementById('govt-colleges').textContent = govtColleges;
        document.getElementById('private-colleges').textContent = privateColleges;
        document.getElementById('min-fee').textContent = `₹${minFee.toLocaleString()}`;
    }

    renderResults() {
        const tbody = document.getElementById('results-tbody');
        tbody.innerHTML = '';

        this.filteredResults.forEach(result => {
            const row = document.createElement('tr');
            
            const chanceIcon = {
                'high': '🟢',
                'moderate': '🟡', 
                'low': '🔴'
            };
            
            const chanceText = {
                'high': 'High',
                'moderate': 'Moderate',
                'low': 'Tough'
            };

            row.innerHTML = `
                <td>
                    <span class="chance-indicator chance-${result.chanceLevel}">
                        ${chanceIcon[result.chanceLevel]} ${chanceText[result.chanceLevel]}
                    </span>
                </td>
                <td>
                    <strong>${result.Institute_Name}</strong><br>
                    <small>${result.Inst_Code}</small>
                </td>
                <td>${result.Place}</td>
                <td>
                    <strong>${result.Branch_Code}</strong><br>
                    <small>${this.branchCodes[result.Branch_Code] || result.Branch_Name || result.Branch_Code}</small>
                </td>
                <td class="font-bold">${result.cutoffRank?.toLocaleString() || 'N/A'}</td>
                <td>₹${result.Tuition_Fee?.toLocaleString() || 'N/A'}</td>
                <td>
                    <span class="college-type type-${result.College_Type?.toLowerCase()}">
                        ${this.collegeTypes[result.College_Type] || result.College_Type}
                    </span>
                </td>
            `;
            
            tbody.appendChild(row);
        });
    }

    applyFilters() {
        const collegeTypeFilter = document.getElementById('college-type-filter').value;
        const feeRangeFilter = parseInt(document.getElementById('fee-range-filter').value) || Infinity;
        const branchFilter = document.getElementById('branch-filter').value;

        const filtered = this.filteredResults.filter(result => {
            if (collegeTypeFilter && result.College_Type !== collegeTypeFilter) return false;
            if (result.Tuition_Fee && result.Tuition_Fee > feeRangeFilter) return false;
            if (branchFilter && result.Branch_Code !== branchFilter) return false;
            return true;
        });

        const originalResults = this.filteredResults;
        this.filteredResults = filtered;
        this.updateStatistics();
        this.renderResults();
        this.filteredResults = originalResults; // Restore for future filtering
    }

    handleSort(column) {
        const direction = this.currentSort.column === column && this.currentSort.direction === 'asc' ? 'desc' : 'asc';
        
        this.filteredResults.sort((a, b) => {
            let valueA, valueB;
            
            switch (column) {
                case 'chance':
                    const chanceOrder = { 'high': 0, 'moderate': 1, 'low': 2 };
                    valueA = chanceOrder[a.chanceLevel];
                    valueB = chanceOrder[b.chanceLevel];
                    break;
                case 'college':
                    valueA = a.Institute_Name?.toLowerCase() || '';
                    valueB = b.Institute_Name?.toLowerCase() || '';
                    break;
                case 'location':
                    valueA = a.Place?.toLowerCase() || '';
                    valueB = b.Place?.toLowerCase() || '';
                    break;
                case 'branch':
                    valueA = a.Branch_Code?.toLowerCase() || '';
                    valueB = b.Branch_Code?.toLowerCase() || '';
                    break;
                case 'cutoff':
                    valueA = a.cutoffRank || 0;
                    valueB = b.cutoffRank || 0;
                    break;
                case 'fee':
                    valueA = a.Tuition_Fee || 0;
                    valueB = b.Tuition_Fee || 0;
                    break;
                case 'type':
                    valueA = a.College_Type?.toLowerCase() || '';
                    valueB = b.College_Type?.toLowerCase() || '';
                    break;
                default:
                    return 0;
            }
            
            if (typeof valueA === 'string') {
                return direction === 'asc' ? valueA.localeCompare(valueB) : valueB.localeCompare(valueA);
            } else {
                return direction === 'asc' ? valueA - valueB : valueB - valueA;
            }
        });

        this.currentSort = { column, direction };
        this.updateSortIndicators(column, direction);
        this.renderResults();
    }

    updateSortIndicators(activeColumn, direction) {
        const headers = document.querySelectorAll('.results-table th[data-sort]');
        headers.forEach(header => {
            header.classList.remove('sort-asc', 'sort-desc');
            if (header.dataset.sort === activeColumn) {
                header.classList.add(direction === 'asc' ? 'sort-asc' : 'sort-desc');
            }
        });
    }

    showLoading() {
        document.getElementById('loading').classList.remove('hidden');
        document.getElementById('results-section').classList.add('hidden');
    }

    hideLoading() {
        document.getElementById('loading').classList.add('hidden');
    }

    showResults() {
        document.getElementById('results-section').classList.remove('hidden');
        document.getElementById('results-section').classList.add('fade-in');
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    new CollegePredictor();
});